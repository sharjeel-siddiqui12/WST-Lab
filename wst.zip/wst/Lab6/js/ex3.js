$(function() {
    $("#datepickerFrom").datepicker();
    $("#datepickerTo").datepicker();
    $("#accordion").accordion();
  });