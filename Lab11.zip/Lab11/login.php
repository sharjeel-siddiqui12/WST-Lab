<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Login Details</title>
    <link rel="stylesheet" href="css/insert.css">

</head>

<body>
    <form action="insert.php" method="post">
        <table align="center">
            <tr>
                <td>Name</td>
                <td><input type="text" name="name" required /></td>
            </tr>
            <tr>
                <td>email</td>
                <td><input type="text" name="email" required /></td>
            </tr>
            <tr>
                <td colspan="2" align="center"><input type="submit" value="submit" name="submit"></td>
            </tr>
        </table>
    </form>
</body>

</html>